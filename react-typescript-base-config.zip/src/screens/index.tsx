import React from 'react'
import { getTranslate, changeLanguage } from '../localization/index';
import { Typography, Button } from '@material-ui/core';

export default function index() {

  const translate = getTranslate();

  return (
    <>

    </>
  )
}
