export default {
    primary: {
        main: "#037fff",
        contrastText: "#FFF"
    },
    secondary: {
        main: "#a4acc4"
    },
    text: {
        primary: "#FFF",
        secondary: "#a4acc4"
    }
}