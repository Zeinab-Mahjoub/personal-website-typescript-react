export default {
    name: "زینب محجوب"
}