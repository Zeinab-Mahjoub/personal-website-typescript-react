export default {
    name: "Zeinab Mahjoub"
}