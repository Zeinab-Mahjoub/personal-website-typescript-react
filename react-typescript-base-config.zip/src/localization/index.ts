import en_us from './en';
import fa_ir from './fa';

export const lang = localStorage.getItem('lang') ?? "en";

export const direction: any  = {
    fa: "rtl",
    en: "ltr"
}

export function getDirection() {
    return direction[lang];
}

const fonts: any = {
    fa: "IRANSans",
    en: "Nunito"
}

export function getFont() {
    return fonts[lang];
}

const translates: any = {
    en: en_us,
    fa: fa_ir
}

export function getTranslate() {
    return translates[lang];
}

export function changeLanguage(newLang: string) {
    if (newLang === lang) {
        return;
    }
    localStorage.setItem('lang', newLang);
    window.location.reload();
}